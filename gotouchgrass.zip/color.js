const Color = (function (/*api*/) {
    var api = {};


    return api;
}());

const colors = true ? {
    "primary": "darkgreen",
    "secondary": "darkviolet",
    "tertiary": "saddlebrown",
    "emergent": "darkgray",
    "rewarding": "gold",
    "hostile": "firebrick",
    "mercurial": "navy",
} : {
    "primary": "gray",
    "secondary": "dimgray",
    "tertiary": "darkgray",
    "emergent": "lightgray",
    "rewarding": "black",
    "hostile": "white",
    "mercurial": "silver",

};
