const Grass = (function (/*api*/) {
    var api = {};

// TODO return type specimen positions for a plant list?
// TODO type specimens will reveal themselves on requirements met
    return api;
}());

// generate type specimens for grass
// annual ryegrass (clusters charge stanima w/o rest)
// kentucky bluegrass (auto-walk on stamina rails)
// tall fescue (reveals nearby hidden twin for stamina)
// crabgrass (double or nothing stamina wager)
// little bluestem (local grass activation)
