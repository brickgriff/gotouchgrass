const inputs = {
  buttons: [],
  keyboard: {},
  mouse: {
    // mouse down
    x_: 0,
    y_: 0,
    // mousemove
    _x: 0,
    _y: 0,
    // to help normalize positions
    // TODO: should these be in terms of mindim units?
    dragMin: .01, // mindim
    dragMax: .05, // mindim
  },
};

function clearInputs() {
  inputs.buttons = [];
}
function pushInput(input) {
  const list = inputs.buttons;
  if (!findInput(input)) list.push(input);
}
function dropInput(input) {
  const list = inputs.buttons;
  if (findInput(input)) list.splice(list.indexOf(input), 1);
}
function findInput(input) {
  return (inputs.buttons.includes(input));
}
function getMouse() {
  return inputs.mouse;
}

function isPressing(vector, range) {
  if (!document.state.events.isPressed) return;
  const mouse = getMouse();
  const hypot = Math.hypot(mouse.x_ - vector.x, mouse.y_ - vector.y);
  return hypot < range;
}

// this should return [-1,1] for vector x and y
function getVector() {
  const mouse = getMouse(); //inputs.mouse;
  let dMax = mouse.dragMax * document.state.mindim;

  const vector = {};

  if (findInput(keybinds.mouseL)) {
    vector.x = mouse._x - mouse.x_;
    vector.y = mouse._y - mouse.y_;
  } else { // keyboard movement have "pointy" diagonals
    vector.x = (findInput(keybinds.right) - findInput(keybinds.left));
    vector.y = (findInput(keybinds.down) - findInput(keybinds.up));
    dMax = 1;
  }

  normalize(vector, dMax);

  return vector;
}

function getNewVector(vector, length, angle) {
  const _vector = {};
  _vector.x = vector.x + (length * Math.cos(angle));
  _vector.y = vector.y + (length * Math.sin(angle));
  return _vector;
}

function normalize(vector, max) {
  // direct length is useful for detecting input
  const hypot = Math.hypot(vector.x, vector.y); // can be as much as 1.4!
  const theta = Math.atan2(vector.y, vector.x); // can be a weird number (~0)

  // we need to normalize diagonals with the angle
  vector.x = Math.min(hypot / max, 1) * Math.cos(theta);
  vector.y = Math.min(hypot / max, 1) * Math.sin(theta);
}


// CHECK BROWSER FEATURES //
// TODO: practice with offscreen canvas
//const ctxOffscreen = canvas.getContext("2d", { willReadFrequently: true });
// TODO: ensure the browser supports innerWidth or clientWidth
if (typeof window === "undefined") {
  console.log("no window");
  try {
    throw new Error("no window");
  } catch (e) {
    console.log(e.message);
  }
}

// HANDLE WINDOW EVENTS //
// suppress system right click menu
window.addEventListener("contextmenu", (e) => { e.preventDefault() });

// trigger resize handler
window.addEventListener("resize", (e) => {
  // inputs.isResized=true;
  // console.log(document.getElementById("inputs").innerHtml);
  //document.getElementById("inputs").isResized=true;
  document.state.events.isResized = true;
});

window.addEventListener("keydown", (e) => {
  // dev
  // e.preventDefault()
  pushInput(e.code);

  // if (e.code !== keybinds.primary) return;

  // inputs.keyboard.x_ = inputs.keyboard._x = inputs.mouse._x || 0;
  // inputs.keyboard.y_ = inputs.keyboard._y = inputs.mouse._y || 0;

});

window.addEventListener("keyup", (e) => {
  dropInput(e.code);
});

window.addEventListener("mousedown", (e) => {
  // dev
  // e.preventDefault();
  pushInput(e.button);
  const state = document.state;
  const ctx = state.ctx;

  if (e.button === keybinds.mouseL) {
    inputs.mouse.x_ = inputs.mouse._x = e.clientX - state.cx;
    inputs.mouse.y_ = inputs.mouse._y = e.clientY - state.cy;

    state.events.isPressed = true;
    state.events.isClicked = false;
    state.events.isDragged = false;
  }

});

window.addEventListener("mouseup", (e) => {
  const state = document.state;
  state.events.isClicked = !state.events.isDragged;

  if (findInput(keybinds.mouseL)) {
    inputs.mouse.x_ = 0;
    inputs.mouse.y_ = 0;
    state.events.isDragged = false;
    state.events.isPressed = false;
  }
  dropInput(e.button);
});

window.addEventListener("mousemove", (e) => {
  const state = document.state;
  inputs.mouse._x = e.clientX - state.cx;
  inputs.mouse._y = e.clientY - state.cy;

  if (findInput(keybinds.mouseL)) {

    const dist = Math.hypot(inputs.mouse._x - inputs.mouse.x_, inputs.mouse._y - inputs.mouse.y_);
    if ((dist >= inputs.mouse.dragMin * state.mindim)) {
      state.events.isDragged = true;
    }
  }
});

const ongoingTouches = [];

function copyTouch({ identifier, pageX, pageY }) {
  return { identifier, pageX, pageY };
}

function ongoingTouchIndexById(idToFind) {
  for (let i = 0; i < ongoingTouches.length; i++) {
    const id = ongoingTouches[i].identifier;

    if (id === idToFind) {
      return i;
    }
  }
  return -1; // not found
}


window.addEventListener("touchstart", (e) => {
  e.preventDefault();
  const state = document.state;
  const touch = e.changedTouches[0];

  const mouseEvent = new MouseEvent("mousedown", {
    button: keybinds.mouseL,
    clientX: touch.clientX,
    clientY: touch.clientY
  });
  window.dispatchEvent(mouseEvent);
}, { passive: false });

var handleTouchFinish = (e) => {
  e.preventDefault()
  const state = document.state;

  const mouseEvent = new MouseEvent("mouseup", {
    button: keybinds.mouseL,
  });
  window.dispatchEvent(mouseEvent);
};

window.addEventListener("touchend", handleTouchFinish);
window.addEventListener("touchcancel", handleTouchFinish);

window.addEventListener("touchmove", (e) => {
  e.preventDefault()
  const state = document.state;
  const touch = e.changedTouches[0];

  const mouseEvent = new MouseEvent("mousemove", {
    button: keybinds.mouseL,
    clientX: touch.clientX,
    clientY: touch.clientY
  });
  window.dispatchEvent(mouseEvent);
}, { passive: false });

// FIXME: how to switch bw WASD and ESDF
let isUsingWASD = false;
const keybinds = {
  up: isUsingWASD ? "KeyW" : "KeyE",
  down: isUsingWASD ? "KeyS" : "KeyD",
  left: isUsingWASD ? "KeyA" : "KeyS",
  right: isUsingWASD ? "KeyD" : "KeyF",

  loosen: isUsingWASD ? "KeyQ" : "KeyW",
  tighten: isUsingWASD ? "KeyE" : "KeyR",
  tertiary: "ShiftLeft",
  secondary: "KeyF",
  primary: "Space",

  debug: "Backquote",
  menu: "Escape",

  mouseL: 0,
  mouseM: 1,
  mouseR: 2,

};
